package com.infinite.week8.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.week8.model.Employee;
import com.infinite.week8.service.EmployeeService;

@RestController
@RequestMapping(value="/api")
public class EmployeeController {
	
	@Autowired
	EmployeeService EmployeeService;
	//autowired to Service layer
	
	
	//saving tha data
	@RequestMapping(value ="/employees", method = RequestMethod.POST)
	public Employee createEmployee(@RequestBody Employee emp) {
		System.out.println("creation of table employee.");
		return EmployeeService.createEmployee(emp);
	}

	//displaying the data
	@RequestMapping(value = "/reademployees", method = RequestMethod.GET)
	public List<Employee> readEmployees() {
		System.out.println("Reading of table employee");
		return EmployeeService.getEmployees();
	}
	
	@Value("${message}") //SPEL language 
	String msg;
	 
	@GetMapping("/welcome") 
	public String getMessage(){ 
		return "Hi "+msg; 
	}
}
