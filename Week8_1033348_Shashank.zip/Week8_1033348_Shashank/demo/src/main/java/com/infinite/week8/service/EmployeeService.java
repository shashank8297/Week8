package com.infinite.week8.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.week8.model.Employee;
import com.infinite.week8.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	//Autowired to Repository
	
	//saving the data
	public Employee createEmployee(Employee emp) {
		return employeeRepository.save(emp);
	}

	//dispaly the data
	public List<Employee> getEmployees() {
		return employeeRepository.findAll();
	}
	
	//delete the data
	public void deleteEmployee(Employee Id){
		employeeRepository.delete(Id);
	}
}
